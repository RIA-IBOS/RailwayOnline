/**
 * Navigation_Start.ts
 *
 * 目标：
 * - 提供一个“通用起终点解析/最近目标要素查找”模块，不依附于任何具体寻路逻辑（Rail/Road/...）。
 * - 输入：任意起点/终点坐标（或 UI 选点得到的坐标） + 目标要素优先级定义（由调用方指定）。
 * - 输出：起点/终点最近目标要素（返回 ID/类型/距离/最近点/代表点），调用方可仅取 ID。
 *
 * 关键规则（按你最新确认）：
 * - “点在面内 => 距离=0” 必须作为通用的面/线要素判定方式存在。
 * - 目标检索：支持“优先级组”，例如铁路新模式：优先 STB（面），若该组不存在/为空/全被过滤，则回退 SBP（点）。
 *
 * 说明：
 * - 本模块默认从 RULE_DATA_SOURCES[worldId] 对应的 files 中拉取 JSON（数组）并解析。
 * - 你也可以通过 options.dataSourceOverride / options.fileFilter / options.itemFilter / options.extraFeatures 注入自定义数据源与要素。
 */

import type { Coordinate, Player, ParsedStation } from '@/types';
import type { ParsedLandmark } from '@/lib/landmarkParser';
import { RULE_DATA_SOURCES, type WorldRuleDataSource } from '@/components/Rules/ruleDataSources';
import { calculateWalkTime, calculateElytraConsumption, type ElytraConsumption } from '@/lib/pathfinding';

const Y_FOR_DISPLAY = 64;

// ------------------------------
// 通用要素类型
// ------------------------------

export type NavGeomType = 'point' | 'polyline' | 'polygon';

export type NavFeature = {
  id: string;
  className: string;
  geomType: NavGeomType;

  /** 点 */
  point?: Coordinate;

  /** 线/面：按序坐标 */
  coords?: Coordinate[];

  /** 原始属性（整个 item） */
  props: any;

  /** 来自哪个文件（调试） */
  sourceFile?: string;
};

export type TargetGroupSpec = {
  /** 本组允许的 Class（例如 ['STB'] 或 ['SBP']） */
  classes: string[];

  /** 可选：进一步过滤（例如仅选择某些 buildingID / 某些标签） */
  predicate?: (f: NavFeature) => boolean;
};

export type NearestTarget = {
  /** 命中的目标要素 */
  feature: NavFeature;

  /** 起点到目标要素的“几何最近距离”（XZ） */
  distance: number;

  /**
   * 最近点：
   * - point：就是 feature.point
   * - polyline/polygon：是投影到线段/边界得到的最近点
   * - 若点在 polygon 内：nearestPoint = origin（距离 0）
   */
  nearestPoint: Coordinate;

  /**
   * 代表点（用于 UI 或接驳段连线）：
   * - point：point
   * - polygon：质心（失败则首点）
   * - polyline：中点（按点序取中间坐标）
   */
  representativePoint: Coordinate;
};

export type NavStartAccessSegment = {
  kind: 'access';
  from: Coordinate;
  to: Coordinate;
  distance: number;
  timeSeconds: number;
  useElytra: boolean;
  elytraConsumption?: ElytraConsumption;
};

export type ResolveTargetsResult = {
  start: NearestTarget | null;
  end: NearestTarget | null;

  /** 可选：接驳段（由调用方决定是否展示/计入时间） */
  startAccess?: NavStartAccessSegment | null;
  endAccess?: NavStartAccessSegment | null;
};

export type LoadRuleFeaturesOptions = {
  worldId: string;

  /**
   * 覆盖 RULE_DATA_SOURCES：用于“计算用文件范畴”接口
   * - baseUrl：JSON 根目录
   * - files：允许仅取部分文件
   */
  dataSourceOverride?: Partial<WorldRuleDataSource>;

  /** 仅保留指定 Class（不传则不限制） */
  onlyClasses?: string[];

  /** 文件级过滤（例如只取 *_Stas.json 等） */
  fileFilter?: (fileName: string) => boolean;

  /** 条目级过滤（例如只取 Class=STB/SBP/STA） */
  itemFilter?: (item: any) => boolean;

  /** 自定义 fetch（便于做缓存/镜像/鉴权） */
  fetcher?: (url: string) => Promise<any[]>;
};

export type ResolveTargetsOptions = {
  worldId: string;

  /**
   * 优先级组：按顺序尝试；若某组“无可用要素”，则回退下一组
   * 例：[{classes:['STB']},{classes:['SBP']}]
   */
  targetGroups: TargetGroupSpec[];

  /** 是否加载 Rule 要素（默认 true） */
  loadRuleFeatures?: boolean;

  /** Rule 加载参数（计算用文件范畴接口等） */
  ruleLoadOptions?: Omit<LoadRuleFeaturesOptions, 'worldId'>;

  /** 额外注入要素（例如未来道路模块引入道路节点） */
  extraFeatures?: NavFeature[];

  /**
   * 是否计算接驳段（默认 false）
   * - true：会输出 startAccess/endAccess（用于地图分段高亮）
   * - 接驳段连接到 representativePoint（非 nearestPoint），更符合“去车站中心/站体点”的直觉
   */
  withAccessSegment?: boolean;

  /** 接驳段是否使用鞘翅（默认 true） */
  useElytra?: boolean;
};

// ------------------------------
// 数据加载（Rule JSON -> NavFeature[]）
// ------------------------------

const _ruleFeatureCache = new Map<string, { key: string; features: NavFeature[] }>();

function buildCacheKey(ds: WorldRuleDataSource, onlyClasses?: string[], fileFilter?: string): string {
  const cls = (onlyClasses ?? []).slice().sort().join(',');
  return `${ds.baseUrl}::${ds.files.join('|')}::${cls}::${fileFilter ?? ''}`;
}

async function defaultFetcher(url: string): Promise<any[]> {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`HTTP ${resp.status} ${resp.statusText}`);
  const data = await resp.json();
  return Array.isArray(data) ? data : [];
}

function detectGeomType(item: any): NavGeomType | null {
  const t = String(item?.Type ?? '').trim();
  if (t === 'Points') return 'point';
  if (t === 'Polyline') return 'polyline';
  if (t === 'Polygon') return 'polygon';

  // 兜底：按字段猜
  if (item?.coordinate) return 'point';
  if (Array.isArray(item?.PLpoints)) return 'polyline';
  if (Array.isArray(item?.Conpoints) || Array.isArray(item?.Flrpoints)) return 'polygon';

  return null;
}

function toCoord(v: any): Coordinate | null {
  if (!v) return null;
  if (Array.isArray(v)) {
    const x = Number(v[0]);
    const y = Number(v[1] ?? Y_FOR_DISPLAY);
    const z = Number(v[2] ?? v[1]); // 兼容 [x,z]
    if (Number.isFinite(x) && Number.isFinite(z)) return { x, y: Number.isFinite(y) ? y : Y_FOR_DISPLAY, z };
    return null;
  }
  if (typeof v === 'object') {
    const x = Number(v.x);
    const y = Number(v.y ?? Y_FOR_DISPLAY);
    const z = Number(v.z);
    if (Number.isFinite(x) && Number.isFinite(z)) return { x, y: Number.isFinite(y) ? y : Y_FOR_DISPLAY, z };
  }
  return null;
}

function toCoordArray(v: any): Coordinate[] {
  if (!Array.isArray(v)) return [];
  const out: Coordinate[] = [];
  for (const p of v) {
    const c = toCoord(p);
    if (c) out.push(c);
  }
  return out;
}

function pickId(item: any, className: string): string {
  const tryField = (k: string): string | null => {
    const s = String(item?.[k] ?? '').trim();
    return s ? s : null;
  };

  const candidates: string[] = [];

  // 常见约定优先
  if (className === 'STB' || className === 'SBP') candidates.push('staBuildingID', 'staBuildingId');
  if (className === 'STA') candidates.push('stationID', 'stationId');
  if (className === 'PLF') candidates.push('platformID', 'platformId');
  if (className === 'RLE') candidates.push('LineID', 'lineID', 'lineId');

  // 你提到的“stationsgroup”体系下的兜底
  candidates.push('ID', 'id', `${className}ID`, `${className.toLowerCase()}ID`, 'name');

  for (const k of candidates) {
    const v = tryField(k);
    if (v) return v;
  }

  return '';
}

function buildNavFeature(item: any, sourceFile?: string): NavFeature | null {
  const className = String(item?.Class ?? '').trim();
  if (!className) return null;

  const geomType = detectGeomType(item);
  if (!geomType) return null;

  const id = pickId(item, className);
  if (!id) return null;

  if (geomType === 'point') {
    const pt = toCoord(item.coordinate);
    if (!pt) return null;
    return { id, className, geomType, point: pt, props: item, sourceFile };
  }

  if (geomType === 'polyline') {
    const coords = toCoordArray(item.PLpoints);
    if (coords.length < 2) return null;
    return { id, className, geomType, coords, props: item, sourceFile };
  }

  // polygon
  const coords = toCoordArray(item.Conpoints ?? item.Flrpoints);
  if (coords.length < 3) return null;
  return { id, className, geomType, coords, props: item, sourceFile };
}

export async function loadRuleNavFeatures(options: LoadRuleFeaturesOptions): Promise<NavFeature[]> {
  const base = RULE_DATA_SOURCES[options.worldId];
  const merged: WorldRuleDataSource = {
    baseUrl: options.dataSourceOverride?.baseUrl ?? base?.baseUrl ?? '/data/JSON',
    files: options.dataSourceOverride?.files ?? base?.files ?? [],
  };

  const cacheKey = buildCacheKey(merged, options.onlyClasses, options.fileFilter ? '1' : '');
  const cacheHit = _ruleFeatureCache.get(options.worldId);
  if (cacheHit && cacheHit.key === cacheKey) return cacheHit.features;

  const fetcher = options.fetcher ?? defaultFetcher;
  const out: NavFeature[] = [];

  for (const file of merged.files) {
    if (options.fileFilter && !options.fileFilter(file)) continue;

    const url = `${merged.baseUrl.replace(/\/$/, '')}/${file}`;
    let arr: any[] = [];
    try {
      arr = await fetcher(url);
    } catch {
      // 可读性优先：RuleDrivenLayer 也允许单文件失败不中断
      continue;
    }

    for (const item of arr) {
      if (options.itemFilter && !options.itemFilter(item)) continue;

      const cls = String(item?.Class ?? '').trim();
      if (options.onlyClasses && options.onlyClasses.length > 0) {
        if (!options.onlyClasses.includes(cls)) continue;
      }

      const f = buildNavFeature(item, file);
      if (f) out.push(f);
    }
  }

  _ruleFeatureCache.set(options.worldId, { key: cacheKey, features: out });
  return out;
}

// ------------------------------
// 几何距离：XZ
// ------------------------------

function distXZ(a: Coordinate, b: Coordinate): number {
  const dx = a.x - b.x;
  const dz = a.z - b.z;
  return Math.hypot(dx, dz);
}

function pointInPolygonXZ(p: Coordinate, poly: Coordinate[]): boolean {
  // ray-casting on XZ
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x;
    const zi = poly[i].z;
    const xj = poly[j].x;
    const zj = poly[j].z;

    const intersect = (zi > p.z) !== (zj > p.z) && p.x < ((xj - xi) * (p.z - zi)) / (zj - zi + 0.0) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function nearestPointOnSegmentXZ(p: Coordinate, a: Coordinate, b: Coordinate): { point: Coordinate; distance: number } {
  const ax = a.x, az = a.z;
  const bx = b.x, bz = b.z;
  const px = p.x, pz = p.z;

  const abx = bx - ax;
  const abz = bz - az;
  const apx = px - ax;
  const apz = pz - az;

  const ab2 = abx * abx + abz * abz;
  if (ab2 <= 1e-12) {
    const d = Math.hypot(px - ax, pz - az);
    return { point: { x: ax, y: a.y ?? Y_FOR_DISPLAY, z: az }, distance: d };
  }

  let t = (apx * abx + apz * abz) / ab2;
  t = Math.max(0, Math.min(1, t));

  const x = ax + t * abx;
  const z = az + t * abz;
  const d = Math.hypot(px - x, pz - z);
  return { point: { x, y: p.y ?? Y_FOR_DISPLAY, z }, distance: d };
}

function nearestPointToPolylineXZ(p: Coordinate, line: Coordinate[]): { point: Coordinate; distance: number } {
  let bestD = Infinity;
  let bestP: Coordinate = { x: line[0].x, y: line[0].y ?? Y_FOR_DISPLAY, z: line[0].z };

  for (let i = 0; i < line.length - 1; i++) {
    const r = nearestPointOnSegmentXZ(p, line[i], line[i + 1]);
    if (r.distance < bestD) {
      bestD = r.distance;
      bestP = r.point;
    }
  }

  return { point: bestP, distance: bestD };
}

function nearestPointToPolygonXZ(p: Coordinate, poly: Coordinate[]): { point: Coordinate; distance: number } {
  // 点在面内 => 0 距离（通用规则）
  if (pointInPolygonXZ(p, poly)) return { point: { ...p }, distance: 0 };

  // 否则：到边界最近
  let bestD = Infinity;
  let bestP: Coordinate = { x: poly[0].x, y: poly[0].y ?? Y_FOR_DISPLAY, z: poly[0].z };

  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const r = nearestPointOnSegmentXZ(p, a, b);
    if (r.distance < bestD) {
      bestD = r.distance;
      bestP = r.point;
    }
  }

  return { point: bestP, distance: bestD };
}

function polygonCentroidXZ(poly: Coordinate[]): Coordinate {
  // 面质心（XZ）；失败则回退首点
  if (poly.length < 3) return { x: poly[0].x, y: poly[0].y ?? Y_FOR_DISPLAY, z: poly[0].z };

  let area = 0;
  let cx = 0;
  let cz = 0;

  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const x0 = poly[j].x;
    const z0 = poly[j].z;
    const x1 = poly[i].x;
    const z1 = poly[i].z;
    const a = x0 * z1 - x1 * z0;
    area += a;
    cx += (x0 + x1) * a;
    cz += (z0 + z1) * a;
  }

  if (Math.abs(area) < 1e-9) return { x: poly[0].x, y: poly[0].y ?? Y_FOR_DISPLAY, z: poly[0].z };

  area *= 0.5;
  cx /= 6 * area;
  cz /= 6 * area;

  if (!Number.isFinite(cx) || !Number.isFinite(cz)) {
    return { x: poly[0].x, y: poly[0].y ?? Y_FOR_DISPLAY, z: poly[0].z };
  }

  return { x: cx, y: poly[0].y ?? Y_FOR_DISPLAY, z: cz };
}

function polylineRepresentativePoint(line: Coordinate[]): Coordinate {
  if (line.length === 0) return { x: 0, y: Y_FOR_DISPLAY, z: 0 };
  return { x: line[Math.floor(line.length / 2)].x, y: line[Math.floor(line.length / 2)].y ?? Y_FOR_DISPLAY, z: line[Math.floor(line.length / 2)].z };
}

function representativePointOfFeature(f: NavFeature): Coordinate {
  if (f.geomType === 'point' && f.point) return { ...f.point, y: f.point.y ?? Y_FOR_DISPLAY };
  if (f.geomType === 'polygon' && f.coords && f.coords.length >= 3) return polygonCentroidXZ(f.coords);
  if (f.geomType === 'polyline' && f.coords && f.coords.length >= 2) return polylineRepresentativePoint(f.coords);
  // 兜底
  return { x: 0, y: Y_FOR_DISPLAY, z: 0 };
}

function nearestDistanceToFeature(origin: Coordinate, f: NavFeature): { distance: number; nearestPoint: Coordinate } {
  if (f.geomType === 'point' && f.point) {
    return { distance: distXZ(origin, f.point), nearestPoint: { ...f.point, y: f.point.y ?? Y_FOR_DISPLAY } };
  }

  if (f.geomType === 'polyline' && f.coords && f.coords.length >= 2) {
    const r = nearestPointToPolylineXZ(origin, f.coords);
    return { distance: r.distance, nearestPoint: r.point };
  }

  if (f.geomType === 'polygon' && f.coords && f.coords.length >= 3) {
    const r = nearestPointToPolygonXZ(origin, f.coords);
    return { distance: r.distance, nearestPoint: r.point };
  }

  return { distance: Infinity, nearestPoint: { ...origin } };
}

// ------------------------------
// 最近目标查找（支持优先级组）
// ------------------------------

export function findNearestTargetInGroups(
  origin: Coordinate,
  features: NavFeature[],
  targetGroups: TargetGroupSpec[]
): NearestTarget | null {
  // 按组顺序：找到“第一组有可用要素”的最近者就返回
  for (const group of targetGroups) {
    const groupFeatures = features.filter(f => group.classes.includes(f.className));
    const filtered = group.predicate ? groupFeatures.filter(group.predicate) : groupFeatures;

    if (filtered.length === 0) continue;

    let best: NearestTarget | null = null;
    for (const f of filtered) {
      const { distance, nearestPoint } = nearestDistanceToFeature(origin, f);
      if (!Number.isFinite(distance)) continue;

      if (!best || distance < best.distance) {
        best = {
          feature: f,
          distance,
          nearestPoint,
          representativePoint: representativePointOfFeature(f),
        };
      }
    }

    if (best) return best;
  }

  return null;
}

export function buildAccessSegment(
  from: Coordinate,
  to: Coordinate,
  useElytra: boolean
): NavStartAccessSegment {
  const distance = distXZ(from, to);
  const timeSeconds = calculateWalkTime(distance, useElytra);
  const seg: NavStartAccessSegment = {
    kind: 'access',
    from: { ...from, y: from.y ?? Y_FOR_DISPLAY },
    to: { ...to, y: to.y ?? Y_FOR_DISPLAY },
    distance,
    timeSeconds,
    useElytra,
  };
  if (useElytra) seg.elytraConsumption = calculateElytraConsumption(distance);
  return seg;
}

/**
 * 解析起点/终点最近目标要素（返回完整信息；调用方若只要 ID，可取 start?.feature.id / end?.feature.id）
 */
export async function resolveNearestTargets(
  startCoord: Coordinate,
  endCoord: Coordinate,
  options: ResolveTargetsOptions
): Promise<ResolveTargetsResult> {
  const all: NavFeature[] = [];

  if (options.loadRuleFeatures !== false) {
    const ruleOpts: LoadRuleFeaturesOptions = {
      worldId: options.worldId,
      ...(options.ruleLoadOptions ?? {}),
      // 性能/可读性优先：仅加载目标组涉及的 class（除非调用方指定 onlyClasses）
      onlyClasses:
        options.ruleLoadOptions?.onlyClasses ??
        Array.from(new Set(options.targetGroups.flatMap(g => g.classes))),
    };

    const rule = await loadRuleNavFeatures(ruleOpts);
    all.push(...rule);
  }

  if (options.extraFeatures && options.extraFeatures.length > 0) {
    all.push(...options.extraFeatures);
  }

  const start = findNearestTargetInGroups(startCoord, all, options.targetGroups);
  const end = findNearestTargetInGroups(endCoord, all, options.targetGroups);

  const res: ResolveTargetsResult = { start, end };

  if (options.withAccessSegment) {
    const useElytra = options.useElytra !== false;

    if (start) {
      // 接驳段连接到代表点（车站建筑中心/点）
      res.startAccess = buildAccessSegment(startCoord, start.representativePoint, useElytra);
    } else {
      res.startAccess = null;
    }

    if (end) {
      res.endAccess = buildAccessSegment(endCoord, end.representativePoint, useElytra);
    } else {
      res.endAccess = null;
    }
  }

  return res;
}

// ------------------------------
// 可选：把 NavigationPanel 现有的数据转换为可选“起终点点要素”（便于未来 UI 复用）
// ------------------------------

export type NavStartCandidateType = 'station' | 'landmark' | 'player' | 'custom';

export type NavStartCandidate = {
  type: NavStartCandidateType;
  name: string;
  coord: Coordinate;
};

export function buildDefaultStartCandidates(args: {
  stations: ParsedStation[];
  landmarks: ParsedLandmark[];
  players?: Player[];
}): NavStartCandidate[] {
  const out: NavStartCandidate[] = [];

  // 站点去重（按 name）
  const stationNames = new Set<string>();
  for (const s of args.stations) {
    if (!stationNames.has(s.name)) {
      stationNames.add(s.name);
      out.push({ type: 'station', name: s.name, coord: s.coord });
    }
  }

  // 地标
  for (const lm of args.landmarks) {
    if (lm.coord) out.push({ type: 'landmark', name: lm.name, coord: lm.coord });
  }

  // 玩家
//  for (const p of args.players ?? []) {
//    out.push({ type: 'player', name: p.name, coord: p.coord });
//  }

  return out;
}

/**
 * 预置：铁路（新）模式的目标优先级
 * - 先 STB（Polygon）
 * - 若 STB 组为空/不可用，再回退 SBP（Point）
 */
export const RAIL_NEW_TARGET_GROUPS: TargetGroupSpec[] = [
  { classes: ['STB'] },
  { classes: ['SBP'] },
];
