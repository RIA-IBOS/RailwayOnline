/**
 * 导航面板组件
 * - 旧版：调用 lib/pathfinding（铁路/传送/步行）
 * - 新增：铁路（新）模式
 *   - 起终点仍从「站点/地标/玩家」中选择（与原逻辑一致）
 *   - 但铁路（新）会：
 *     1) 调用 Navigation_Start：将起终点坐标映射到最近的 STB/SBP（优先 STB，找不到则 SBP）
 *     2) 调用 Navigation_Rail：在规则（Rule）铁路体系（STA/PLF/STB/SBP/RLE）上计算最短路/最少换乘
 *   - 输出结果：
 *     - 每个铁路段右侧独立开关展开“途经站”
 *     - 概览区以线路 color 分段展示（类似你提供的截图）
 *     - onRouteFound 仍保持传回 Array<{coord}>，但会额外挂载 styledSegments / stationMarkers（后续 MapContainer/RouteHighlightLayer 可直接复用）
 */

import { useState, useRef, useEffect, useMemo } from 'react';
import {
  X,
  ArrowUpDown,
  Train,
  Home,
  Footprints,
  User,
  Zap,
  Clock,
  Rocket,
  Shield,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import type { ParsedStation, ParsedLine, Coordinate, Player, TravelMode } from '@/types';
import type { ParsedLandmark } from '@/lib/landmarkParser';
import {
  buildRailwayGraph,
  simplifyPath,
  findAutoPath,
  findRailOnlyPath,
  findWalkPath,
  calculateEstimatedTime,
  calculateElytraConsumption,
  calculateWalkTime,
  calculateRailTime,
  MultiModePathResult,
} from '@/lib/pathfinding';
import { findTeleportPath, extractToriiList } from '@/lib/toriiTeleport';

// 新铁路模块（你已在项目中添加）
// 注意：为提升兼容性，这里使用命名空间导入 + 运行时兜底调用。
// 若你的导出函数名不同，只需在本文件的 callNavStart/callNavRail 中改一个映射即可。
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import * as NavStart from './Navigation_Start';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import * as NavRail from './Navigation_Rail';

// ---------------------------
// utils
// ---------------------------

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds)) return '-';
  if (seconds < 60) return `${Math.round(seconds)}秒`;
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  return secs > 0 ? `${mins}分${secs}秒` : `${mins}分钟`;
}

function formatArrivalTime(secondsFromNow: number): string {
  if (!Number.isFinite(secondsFromNow)) return '';
  const t = new Date(Date.now() + Math.max(0, secondsFromNow) * 1000);
  const hh = String(t.getHours()).padStart(2, '0');
  const mm = String(t.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

function safeNumber(v: unknown, fallback = 0): number {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function uniq(arr: string[]): string[] {
  const out: string[] = [];
  const s = new Set<string>();
  for (const v of arr) {
    const k = `${v}`;
    if (!s.has(k)) {
      s.add(k);
      out.push(v);
    }
  }
  return out;
}

// ---------------------------
// types
// ---------------------------

interface NavigationPanelProps {
  stations: ParsedStation[];
  lines: ParsedLine[];
  landmarks: ParsedLandmark[];
  players?: Player[];
  worldId: string;
  onRouteFound?: (path: Array<{ coord: Coordinate }>) => void;
  onClose: () => void;
  onPointClick?: (coord: Coordinate) => void;
}

interface SearchItem {
  type: 'station' | 'landmark' | 'player';
  name: string;
  coord: Coordinate;
}

// UI：在 TravelMode 的基础上增加 rail_new
type TravelModePanel = TravelMode | 'rail_new';

// 新铁路：最小化依赖的显示结构
type RailNewLegKind = 'access' | 'walk' | 'rail' | 'transfer';

interface RailNewLegBase {
  kind: RailNewLegKind;
}

interface RailNewWalkLeg extends RailNewLegBase {
  kind: 'access' | 'walk' | 'transfer';
  label: string;
  from: Coordinate;
  to: Coordinate;
  distance: number;
  timeSeconds: number;
  dashed?: boolean;
}

interface RailNewRailLeg extends RailNewLegBase {
  kind: 'rail';
  lineKey: string;
  lineName: string;
  color: string;
  fromStation: string;
  toStation: string;
  viaStations: string[];
  distance: number;
  timeSeconds: number;
  // 用于联络线“xxx/xxx/xxx”拼接显示
  lineNameChain?: string[];
}

type RailNewLeg = RailNewWalkLeg | RailNewRailLeg;

interface RailNewPlan {
  found: boolean;
  totalTimeSeconds: number;
  totalDistance: number;
  totalTransfers: number;
  legs: RailNewLeg[];
  // 可选：由 Navigation_Rail 返回的高亮数据
  routeHighlight?: {
    path?: Array<{ coord: Coordinate }>;
    styledSegments?: unknown[];
    stationMarkers?: unknown[];
  };
}

// 让 onRouteFound 仍传 Array<{coord}>，但在数组对象上挂载更多字段。
export type RoutePathV2 = Array<{ coord: Coordinate }> & {
  styledSegments?: unknown[];
  stationMarkers?: unknown[];
};

// ---------------------------
// Mode config
// ---------------------------

const TRAVEL_MODES: Array<{ mode: TravelModePanel; label: string; icon: typeof Train }> = [
  { mode: 'rail_new', label: '铁路(新)', icon: Train },
  { mode: 'rail', label: '铁路', icon: Train },
  { mode: 'teleport', label: '传送', icon: Zap },
  { mode: 'walk', label: '步行', icon: Footprints },
];

// 新铁路：可调整参数（默认值可按你的需要随时改）
const DEFAULT_RAIL_NEW_CONFIG = {
  // 站内换乘步行速度（m/s）
  transferWalkSpeed: 3.0,
  // 铁路乘坐速度（m/s）
  railRideSpeed: 16.0,
  // 站内换乘成本阈值：距离 cost = dist / factor（你此前要求的“十分之一权重”本质等价）
  transferCostFactor: 10.0,
  // 正常站台同台换乘成本（用于让联络线连接节点优先）
  normalPlatformTransferCost: 5.0,
};

// ---------------------------
// Search input
// ---------------------------

interface PointSearchInputProps {
  value: SearchItem | null;
  onChange: (item: SearchItem | null) => void;
  items: SearchItem[];
  placeholder: string;
  label: string;
}

function PointSearchInput({ value, onChange, items, placeholder, label }: PointSearchInputProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState(value?.name || '');
  const containerRef = useRef<HTMLDivElement>(null);

  const filteredItems = useMemo(() => {
    if (query.length === 0) return [];
    const q = query.toLowerCase();
    return items.filter((item) => item.name.toLowerCase().includes(q)).slice(0, 10);
  }, [query, items]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    setQuery(value?.name || '');
  }, [value]);

  const handleSelect = (item: SearchItem) => {
    setQuery(item.name);
    onChange(item);
    setIsOpen(false);
  };

  return (
    <div ref={containerRef} className="relative">
      <label className="text-xs text-gray-500 mb-1 block">{label}</label>
      <input
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setIsOpen(true);
          const match = items.find((item) => item.name === e.target.value);
          onChange(match || null);
        }}
        onFocus={() => setIsOpen(true)}
        placeholder={placeholder}
        className="w-full px-3 py-2 border rounded text-sm outline-none focus:border-blue-400"
      />

      {isOpen && filteredItems.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-lg shadow-lg max-h-48 overflow-y-auto z-50 border">
          {filteredItems.map((item, idx) => (
            <button
              key={`${item.type}-${item.name}-${idx}`}
              className="w-full px-3 py-2 text-left text-sm hover:bg-gray-100 border-b border-gray-50 last:border-b-0 flex items-center gap-2"
              onClick={() => handleSelect(item)}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                  item.type === 'station'
                    ? 'bg-blue-500 text-white'
                    : item.type === 'player'
                      ? 'bg-cyan-500 text-white'
                      : 'bg-orange-500 text-white'
                }`}
              >
                {item.type === 'station' ? (
                  <Train className="w-3 h-3" />
                ) : item.type === 'player' ? (
                  <User className="w-3 h-3" />
                ) : (
                  <Home className="w-3 h-3" />
                )}
              </span>
              <span>{item.name}</span>
              <span className="text-xs text-gray-400 ml-auto">
                {item.type === 'station' ? '站点' : item.type === 'player' ? '玩家' : '地标'}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------
// New Rail: adapters
// ---------------------------

async function callNavStartNearestBuildings(args: {
  worldId: string;
  start: Coordinate;
  end: Coordinate;
  // 目标要素类型：默认 STB/SBP（优先 STB）
  targetKinds?: Array<'STB' | 'SBP'>;
}): Promise<{ startTargetId: string; endTargetId: string } | null> {
  const mod: any = NavStart as any;

  // 你真正实现的是 resolveNearestTargets(startCoord, endCoord, options)
  const fn =
    mod.resolveNearestTargets ||
    mod.findNearestTargets ||
    mod.findNearest ||
    mod.default;

  if (typeof fn !== 'function') return null;

  // 目标组：按顺序优先 STB，再 SBP（与你的要求一致）
  const targetGroups =
    mod.RAIL_NEW_TARGET_GROUPS ??
    [
      { name: 'STB', classes: ['STB'], representative: 'centroid' },
      { name: 'SBP', classes: ['SBP'], representative: 'point' },
    ];

  const preferKinds = args.targetKinds?.length ? args.targetKinds : (['STB', 'SBP'] as const);
  const orderedGroups = targetGroups.filter((g: any) => preferKinds.includes(g.classes?.[0]));

  try {
    // ✅ 正确位置参数调用
    const res = await fn(args.start, args.end, {
      worldId: args.worldId,
      targetGroups: orderedGroups,
      withAccessSegment: true,
      useElytra: true,
      // 保留可配置接口：如需只加载某些类，可在 ruleLoadOptions.onlyClasses 设置
      ruleLoadOptions: {
        onlyClasses: Array.from(new Set(orderedGroups.flatMap((g: any) => g.classes))),
      },
    });

    const startId =
      res?.start?.feature?.id ??
      res?.startTargetId ??
      res?.startId ??
      null;

    const endId =
      res?.end?.feature?.id ??
      res?.endTargetId ??
      res?.endId ??
      null;

    if (typeof startId === 'string' && typeof endId === 'string') {
      return { startTargetId: startId, endTargetId: endId };
    }
    return null;
  } catch {
    return null;
  }
}


async function callNavRailPlan(args: {
  worldId: string;
  startBuildingId: string;
  endBuildingId: string;
  preferLessTransfer: boolean;
  config: typeof DEFAULT_RAIL_NEW_CONFIG;
}): Promise<RailNewPlan | null> {
  const mod: any = NavRail as any;

  // 你实现里最常见的是 computeRailPlanBetweenBuildings
  const fn =
    mod.computeRailPlanBetweenBuildings ||
    mod.computeRailPlan ||
    mod.planRail ||
    mod.computeRailRoute ||
    mod.default;

  if (typeof fn !== 'function') return null;

  const options = {
    ...args.config,
    preferLessTransfer: args.preferLessTransfer,
  };

  let raw: any;
  try {
    // ✅ 优先用“位置参数签名”
    // fn(worldId, startBuildingId, endBuildingId, options)
    raw = await fn(args.worldId, args.startBuildingId, args.endBuildingId, options);
  } catch {
    try {
      // 兼容“payload 签名”
      raw = await fn({
        worldId: args.worldId,
        startBuildingId: args.startBuildingId,
        endBuildingId: args.endBuildingId,
        options,
        config: args.config,
        preferLessTransfer: args.preferLessTransfer,
      });
    } catch {
      return null;
    }
  }

  if (!raw) return null;

  // --- normalize（保留你原来的归一化逻辑即可）---
  const found = !!(raw.found ?? raw.ok ?? raw.success);
  const totalTimeSeconds = safeNumber(raw.totalTimeSeconds ?? raw.timeSeconds ?? raw.totalTime ?? raw.totalSeconds, 0);
  const totalDistance = safeNumber(raw.totalDistance ?? raw.distance ?? raw.totalMeters, 0);
  const totalTransfers = safeNumber(raw.totalTransfers ?? raw.transfers ?? raw.transferCount, 0);

  const rawLegs: any[] =
    raw.legs ||
    raw.segments ||
    raw.steps ||
    raw.pathSegments ||
    [];

  const legs: RailNewLeg[] = rawLegs
    .map((seg: any): RailNewLeg | null => {
      const kind = (seg.kind || seg.type || seg.segmentType || '').toString();

      if (kind === 'rail' || seg.lineKey || seg.lineName || seg.viaStations || seg.stations) {
        const lineKey = String(seg.lineKey ?? seg.lineId ?? seg.key ?? seg.id ?? '');
        const lineName = String(seg.lineName ?? seg.displayName ?? seg.name ?? lineKey);
        const color = String(seg.color ?? seg.lineColor ?? '#3b82f6');
        const fromStation = String(seg.fromStation ?? seg.from ?? seg.startStation ?? '');
        const toStation = String(seg.toStation ?? seg.to ?? seg.endStation ?? '');
        const viaStations: string[] =
          Array.isArray(seg.viaStations)
            ? seg.viaStations.map(String)
            : Array.isArray(seg.stations)
              ? seg.stations.map(String)
              : [];

        const distance = safeNumber(seg.distance ?? seg.distanceMeters ?? seg.meters, 0);
        const timeSeconds = safeNumber(seg.timeSeconds ?? seg.durationSeconds ?? seg.seconds, 0);

        return {
          kind: 'rail',
          lineKey,
          lineName,
          color,
          fromStation,
          toStation,
          viaStations: uniq(viaStations.length ? viaStations : [fromStation, toStation].filter(Boolean)),
          distance,
          timeSeconds,
          // 可选字段（如果你 rail 模块输出了）
          lineNameChain: Array.isArray(seg.lineNameChain) ? seg.lineNameChain.map(String) : undefined,
        };
      }

      // transfer / access 等保持你原来逻辑
      return null;
    })
    .filter(Boolean) as RailNewLeg[];

  return {
    found,
    totalTimeSeconds,
    totalDistance,
    totalTransfers,
    legs,
    // 把你 rail 模块给的 highlight 数据透传（用于新 RouteHighlightLayer）
    highlight: raw.highlight ?? raw.routeHighlight ?? null,
  };
}


// ---------------------------
// Component
// ---------------------------

export function NavigationPanel({
  stations,
  lines,
  landmarks,
  players = [],
  worldId,
  onRouteFound,
  onClose,
  onPointClick,
}: NavigationPanelProps) {
  const [startPoint, setStartPoint] = useState<SearchItem | null>(null);
  const [endPoint, setEndPoint] = useState<SearchItem | null>(null);
  const [travelMode, setTravelMode] = useState<TravelModePanel>('rail');
  const [preferLessTransfer, setPreferLessTransfer] = useState(true);
  const [useElytra, setUseElytra] = useState(true);

  const [resultLegacy, setResultLegacy] = useState<MultiModePathResult | null>(null);
  const [resultRailNew, setResultRailNew] = useState<RailNewPlan | null>(null);
  const [searching, setSearching] = useState(false);

  // rail_new：每段展开状态
  const [expandedRailLegs, setExpandedRailLegs] = useState<Record<string, boolean>>({});

  const formatLineName = (lineId: string): string => {
    const line = lines.find((l) => l.lineId === lineId);
    if (line) return line.bureau === 'RMP' ? line.line : `${line.bureau}-${line.line}`;
    return lineId;
  };

  const searchItems = useMemo(() => {
    const items: SearchItem[] = [];

    // 站点（去重 name）
    const stationNames = new Set<string>();
    for (const station of stations) {
      if (!stationNames.has(station.name)) {
        stationNames.add(station.name);
        items.push({ type: 'station', name: station.name, coord: station.coord });
      }
    }

    // 地标
    for (const landmark of landmarks) {
      if (landmark.coord) items.push({ type: 'landmark', name: landmark.name, coord: landmark.coord });
    }

    // 玩家
    for (const player of players) {
      items.push({
        type: 'player',
        name: player.name,
        coord: { x: player.x, y: player.y, z: player.z },
      });
    }

    return items;
  }, [stations, landmarks, players]);

  const railwayGraph = useMemo(() => buildRailwayGraph(lines), [lines]);
  const toriiList = useMemo(() => extractToriiList(landmarks), [landmarks]);

  // 交换起终点
  const handleSwap = () => {
    const temp = startPoint;
    setStartPoint(endPoint);
    setEndPoint(temp);
    setResultLegacy(null);
    setResultRailNew(null);
  };

  // 新铁路：展开/收起途经站
  const toggleRailLegExpand = (key: string) => {
    setExpandedRailLegs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // 搜索
  const handleSearch = async () => {
    if (!startPoint || !endPoint) return;

    const isSameLocation = startPoint.coord.x === endPoint.coord.x && startPoint.coord.z === endPoint.coord.z;
    if (isSameLocation) {
      setResultLegacy({
        found: false,
        mode: 'walk',
        segments: [],
        totalWalkDistance: 0,
        totalRailDistance: 0,
        totalTransfers: 0,
        teleportCount: 0,
        reverseTeleportCount: 0,
      });
      setResultRailNew({ found: false, totalTimeSeconds: 0, totalDistance: 0, totalTransfers: 0, legs: [] });
      return;
    }

    setSearching(true);

    try {
      if (travelMode === 'rail_new') {
        // 1) 最近 STB/SBP
        const nearest = await callNavStartNearestBuildings({
          worldId,
          start: startPoint.coord,
          end: endPoint.coord,
          targetKinds: ['STB', 'SBP'],
        });

        if (!nearest) {
          setResultRailNew({ found: false, totalTimeSeconds: 0, totalDistance: 0, totalTransfers: 0, legs: [] });
          setResultLegacy(null);
          return;
        }

        // 2) 计算铁路
        const plan = await callNavRailPlan({
          worldId,
          startBuildingId: nearest.startTargetId,
          endBuildingId: nearest.endTargetId,
          preferLessTransfer,
          config: DEFAULT_RAIL_NEW_CONFIG,
        });

        if (!plan || !plan.found) {
          setResultRailNew(plan || { found: false, totalTimeSeconds: 0, totalDistance: 0, totalTransfers: 0, legs: [] });
          setResultLegacy(null);
          return;
        }

        setResultRailNew(plan);
        setResultLegacy(null);

        // 3) 通知高亮
        if (onRouteFound) {
          const routeHighlight = plan.routeHighlight;
          const pathArr: Array<{ coord: Coordinate }> =
            (routeHighlight?.path && Array.isArray(routeHighlight.path) ? routeHighlight.path : []) as any;

          // 若模块未返回 path，则退化为：起点->终点 直线（保证不崩溃）
          const fallbackPath: Array<{ coord: Coordinate }> = [
            { coord: startPoint.coord },
            { coord: endPoint.coord },
          ];

          const base = (pathArr && pathArr.length > 0 ? pathArr : fallbackPath) as RoutePathV2;
          base.styledSegments = (routeHighlight?.styledSegments as any) || undefined;
          base.stationMarkers = (routeHighlight?.stationMarkers as any) || undefined;
          onRouteFound(base);
        }

        return;
      }

      // ---------------------------
      // legacy pathfinding
      // ---------------------------

      let pathResult: MultiModePathResult;

      switch (travelMode) {
        case 'walk':
          pathResult = findWalkPath(startPoint.coord, endPoint.coord);
          break;

        case 'teleport': {
          const teleportPath = findTeleportPath(startPoint.coord, endPoint.coord, toriiList, worldId);
          let reverseTeleportCount = 0;
          const teleportSegments = teleportPath.segments.map((seg) => {
            if (seg.type === 'teleport' && seg.torii) {
              const isReverse = seg.destinationName === seg.torii.name;
              if (isReverse) reverseTeleportCount++;
              return {
                type: 'teleport' as const,
                torii: seg.torii,
                destination: seg.to,
                destinationName: seg.destinationName || '传送点',
                isReverse,
              };
            }
            return { type: 'walk' as const, from: seg.from, to: seg.to, distance: seg.distance };
          });
          pathResult = {
            found: teleportPath.found,
            mode: 'teleport',
            segments: teleportSegments,
            totalWalkDistance: teleportPath.totalWalkDistance,
            totalRailDistance: 0,
            totalTransfers: 0,
            teleportCount: teleportPath.teleportCount - reverseTeleportCount,
            reverseTeleportCount,
          };
          break;
        }

        case 'rail':
          pathResult = findRailOnlyPath(startPoint.coord, endPoint.coord, railwayGraph, stations, preferLessTransfer);
          break;

        case 'auto':
        default:
          pathResult = findAutoPath(startPoint.coord, endPoint.coord, railwayGraph, landmarks, stations, worldId, preferLessTransfer);
          break;
      }

      setResultLegacy(pathResult);
      setResultRailNew(null);

      if (onRouteFound && pathResult.found) {
        const path: Array<{ coord: Coordinate }> = [];
        for (const segment of pathResult.segments) {
          if (segment.type === 'walk') {
            path.push({ coord: segment.from });
            path.push({ coord: segment.to });
          } else if (segment.type === 'rail') {
            for (const node of segment.railPath.path) path.push({ coord: node.coord });
          } else if (segment.type === 'teleport') {
            path.push({ coord: segment.torii.coord });
            path.push({ coord: segment.destination });
          }
        }
        onRouteFound(path);
      }
    } finally {
      setSearching(false);
    }
  };

  // ---------------------------
  // Render
  // ---------------------------

  const hasResult = !!(resultLegacy || resultRailNew);

  return (
    <div className="bg-white rounded-lg shadow-lg w-full sm:w-72 max-h-[60vh] sm:max-h-[70vh] flex flex-col">
      {/* 标题 */}
      <div className="flex items-center justify-between px-4 py-3 border-b flex-shrink-0">
        <h3 className="font-bold text-gray-800">路径规划</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* 模式选择 */}
      <div className="flex border-b">
        {TRAVEL_MODES.map(({ mode, label, icon: Icon }) => (
          <button
            key={mode}
            className={`flex-1 py-2 px-1 flex flex-col items-center gap-0.5 text-xs transition-colors ${
              travelMode === mode
                ? 'text-blue-600 border-b-2 border-blue-500 bg-blue-50'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
            onClick={() => {
              setTravelMode(mode);
              setResultLegacy(null);
              setResultRailNew(null);
            }}
          >
            <Icon className="w-4 h-4" />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* 输入区域 */}
      <div className="p-3 border-b">
        <div className="flex items-start gap-2 mb-2">
          <div className="flex-1">
            <PointSearchInput
              value={startPoint}
              onChange={(v) => {
                setStartPoint(v);
                setResultLegacy(null);
                setResultRailNew(null);
              }}
              items={searchItems}
              placeholder="输入起点（站点/地标）..."
              label="起点"
            />
          </div>
          <button
            onClick={handleSwap}
            className="mt-6 p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
            title="交换起终点"
          >
            <ArrowUpDown className="w-4 h-4" />
          </button>
        </div>

        <div className="mb-2">
          <PointSearchInput
            value={endPoint}
            onChange={(v) => {
              setEndPoint(v);
              setResultLegacy(null);
              setResultRailNew(null);
            }}
            items={searchItems}
            placeholder="输入终点（站点/地标）..."
            label="终点"
          />
        </div>

        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            {(travelMode === 'rail' || travelMode === 'auto' || travelMode === 'rail_new') && (
              <label className="flex items-center gap-1.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={preferLessTransfer}
                  onChange={(e) => {
                    setPreferLessTransfer(e.target.checked);
                    setResultLegacy(null);
                    setResultRailNew(null);
                  }}
                  className="w-3 h-3"
                />
                <span className="text-gray-600">少换乘</span>
              </label>
            )}

            <label className="flex items-center gap-1.5 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={useElytra}
                onChange={(e) => {
                  setUseElytra(e.target.checked);
                  setResultLegacy(null);
                  setResultRailNew(null);
                }}
                className="w-3 h-3"
              />
              <span className="text-gray-600">鞘翅</span>
            </label>
          </div>

          <button
            onClick={() => void handleSearch()}
            disabled={!startPoint || !endPoint || searching}
            className="px-4 py-1.5 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-xs font-medium"
          >
            {searching ? '搜索中...' : '搜索'}
          </button>
        </div>
      </div>

      {/* 结果区域 */}
      {hasResult && (
        <div className="flex-1 overflow-y-auto p-3">
          {/* 新铁路结果 */}
          {travelMode === 'rail_new' && resultRailNew && (
            <>
              {resultRailNew.found ? (
                <>
                  {/* 概览（截图风格简化版） */}
                  <div className="bg-gray-50 rounded-lg p-3 mb-3">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-semibold text-gray-800">铁路（新）</div>
                      <div className="text-xs text-gray-500">
                        到达时间 <span className="font-medium text-gray-800">{formatArrivalTime(resultRailNew.totalTimeSeconds)}</span>
                      </div>
                    </div>

                    {/* 线路 pills */}
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {resultRailNew.legs
                        .filter((l) => l.kind === 'rail')
                        .map((l, idx) => {
                          const leg = l as RailNewRailLeg;
                          return (
                            <div
                              key={`pill-${idx}`}
                              className="px-3 py-1 rounded text-xs font-medium text-white"
                              style={{ backgroundColor: leg.color || '#3b82f6' }}
                              title={leg.lineKey}
                            >
                              {leg.lineNameChain?.length ? leg.lineNameChain.join('/') : leg.lineName}
                            </div>
                          );
                        })}
                    </div>

                    <div className="mt-2 text-xs text-gray-600">
                      全程约 <span className="font-medium text-gray-800">{formatTime(resultRailNew.totalTimeSeconds)}</span>
                      {resultRailNew.totalTransfers > 0 && (
                        <span className="ml-3">换乘 <span className="font-medium text-blue-600">{resultRailNew.totalTransfers}</span> 次</span>
                      )}
                    </div>
                  </div>

                  {/* 详情 timeline */}
                  <div className="space-y-2">
                    {resultRailNew.legs.map((leg, index) => {
                      if (leg.kind === 'rail') {
                        const k = `${index}`;
                        const expanded = !!expandedRailLegs[k];
                        const displayLineName = leg.lineNameChain?.length ? leg.lineNameChain.join('/') : leg.lineName;
                        const stationsList = leg.viaStations?.length ? leg.viaStations : [leg.fromStation, leg.toStation].filter(Boolean);
                        const first = stationsList[0] || leg.fromStation;
                        const last = stationsList[stationsList.length - 1] || leg.toStation;
                        const mid = stationsList.slice(1, Math.max(1, stationsList.length - 1));

                        return (
                          <div key={`rail-leg-${index}`} className="relative pl-5">
                            {index < resultRailNew.legs.length - 1 && (
                              <div
                                className="absolute left-[7px] top-5 bottom-0 w-0.5"
                                style={{ backgroundColor: leg.color || '#3b82f6' }}
                              />
                            )}
                            <div
                              className="absolute left-0 top-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center"
                              style={{ backgroundColor: leg.color || '#3b82f6' }}
                            >
                              <Train className="w-2.5 h-2.5" />
                            </div>

                            <div className="rounded p-2 border" style={{ borderColor: `${leg.color || '#3b82f6'}55` }}>
                              <div className="flex items-start gap-2">
                                <div className="flex-1 min-w-0">
                                  <div className="text-[10px] font-medium mb-0.5" style={{ color: leg.color || '#3b82f6' }}>
                                    {displayLineName}
                                    <span className="text-gray-400 ml-1">({formatTime(leg.timeSeconds)})</span>
                                  </div>
                                  <div className="text-xs text-gray-800 truncate">
                                    <span className="font-medium">{first}</span>
                                    {stationsList.length > 2 ? (
                                      <span className="text-gray-400 mx-1">→ {stationsList.length - 2}站 →</span>
                                    ) : (
                                      <span className="text-gray-400 mx-1">→</span>
                                    )}
                                    <span className="font-medium">{last}</span>
                                  </div>
                                </div>

                                <button
                                  className="flex items-center gap-1 text-[10px] text-gray-600 hover:text-gray-800 flex-shrink-0"
                                  onClick={() => toggleRailLegExpand(k)}
                                  title="展开/收起途经站"
                                >
                                  <span>途经</span>
                                  {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                                </button>
                              </div>

                              {expanded && mid.length > 0 && (
                                <div className="mt-2 flex flex-wrap gap-1">
                                  {mid.map((s, i) => (
                                    <span
                                      key={`${k}-mid-${i}`}
                                      className="px-2 py-0.5 rounded text-[10px] text-white"
                                      style={{ backgroundColor: leg.color || '#3b82f6' }}
                                    >
                                      {s}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      }

                      // walk/access/transfer（接驳段也显示）
                      const icon = leg.kind === 'transfer' ? ChevronRight : Footprints;
                      const Icon = icon;
                      const bg = leg.kind === 'transfer' ? 'bg-gray-50' : 'bg-green-50';
                      const fg = leg.kind === 'transfer' ? 'text-gray-600' : 'text-green-600';

                      return (
                        <div key={`walk-leg-${index}`} className="relative pl-5">
                          {index < resultRailNew.legs.length - 1 && (
                            <div
                              className={`absolute left-[7px] top-5 bottom-0 w-0.5 ${leg.dashed ? 'bg-transparent' : 'bg-gray-200'}`}
                              style={leg.dashed ? { borderLeft: '2px dashed #cbd5e1' } : undefined}
                            />
                          )}
                          <div className={`absolute left-0 top-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center ${leg.kind === 'transfer' ? 'bg-gray-500' : 'bg-green-500'}`}>
                            <Icon className="w-2.5 h-2.5" />
                          </div>

                          <div className={`${bg} rounded p-2`}>
                            <div className={`text-[10px] ${fg} font-medium mb-0.5`}>
                              {leg.label} {Math.round(leg.distance)}m
                              <span className="text-gray-400 ml-1">({formatTime(leg.timeSeconds)})</span>
                            </div>
                            <div className="text-xs text-gray-800">
                              <button className="hover:underline" onClick={() => onPointClick?.(leg.from)}>
                                ({Math.round(leg.from.x)}, {Math.round(leg.from.z)})
                              </button>
                              <span className="text-gray-400 mx-1">→</span>
                              <button className="hover:underline" onClick={() => onPointClick?.(leg.to)}>
                                ({Math.round(leg.to.x)}, {Math.round(leg.to.z)})
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              ) : (
                <div className="text-center text-gray-500 py-4 text-sm">
                  {startPoint?.coord.x === endPoint?.coord.x && startPoint?.coord.z === endPoint?.coord.z
                    ? '起点和终点相同'
                    : '未找到可用路线（请检查：站台 Situation/Available、线路方向、换乘归属 STB/SBP 等）'}
                </div>
              )}
            </>
          )}

          {/* 旧模式结果 */}
          {travelMode !== 'rail_new' && resultLegacy && (
            <>
              {resultLegacy.found ? (
                <>
                  <div className="flex items-center gap-3 mb-3 text-xs flex-wrap">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-gray-400" />
                      <span className="text-gray-500">预计:</span>
                      <span className="font-medium text-orange-600">{formatTime(calculateEstimatedTime(resultLegacy, useElytra))}</span>
                    </div>
                    {resultLegacy.totalTransfers > 0 && (
                      <div className="flex items-center gap-1">
                        <span className="text-gray-500">换乘:</span>
                        <span className="font-medium text-blue-600">{resultLegacy.totalTransfers}次</span>
                      </div>
                    )}
                    {resultLegacy.teleportCount > 0 && (
                      <div className="flex items-center gap-1">
                        <span className="text-gray-500">传送:</span>
                        <span className="font-medium text-purple-600">{resultLegacy.teleportCount}次</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <span className="text-gray-500">{useElytra ? '飞行' : '步行'}:</span>
                      <span className="font-medium">{Math.round(resultLegacy.totalWalkDistance)}m</span>
                    </div>
                    {resultLegacy.totalRailDistance > 0 && (
                      <div className="flex items-center gap-1">
                        <span className="text-gray-500">铁路:</span>
                        <span className="font-medium">{Math.round(resultLegacy.totalRailDistance)}m</span>
                      </div>
                    )}
                  </div>

                  {useElytra && resultLegacy.totalWalkDistance > 0 && (() => {
                    const consumption = calculateElytraConsumption(resultLegacy.totalWalkDistance);
                    return (
                      <div className="bg-amber-50 rounded p-2 mb-3 text-xs">
                        <div className="flex items-center gap-1 mb-1 text-amber-700 font-medium">
                          <Rocket className="w-3 h-3" />
                          <span>鞘翅飞行消耗</span>
                        </div>
                        <div className="flex items-center gap-3 flex-wrap text-gray-600">
                          <div className="flex items-center gap-1">
                            <Rocket className="w-3 h-3 text-red-500" />
                            <span>烟花: </span>
                            <span className="font-medium text-red-600">~{consumption.fireworksUsed}个</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Shield className="w-3 h-3 text-cyan-500" />
                            <span>耐久: </span>
                            <span className="font-medium text-cyan-600">{Math.round((consumption.durabilityUsed / 432) * 100)}%</span>
                            <span className="text-gray-400">({Math.round((consumption.durabilityUsedUnbreaking / 432) * 100)}% 耐久III)</span>
                          </div>
                        </div>
                        {consumption.elytraCount > 1 && (
                          <div className="mt-1 text-amber-600">⚠️ 需要 {consumption.elytraCount} 个鞘翅（或 {consumption.elytraCountUnbreaking} 个耐久III鞘翅）</div>
                        )}
                      </div>
                    );
                  })()}

                  <div className="space-y-2">
                    {resultLegacy.segments.map((segment, index) => {
                      if (segment.type === 'walk') {
                        const walkTime = calculateWalkTime(segment.distance, useElytra);
                        return (
                          <div key={index} className="relative pl-5">
                            {index < resultLegacy.segments.length - 1 && (
                              <div className="absolute left-[7px] top-5 bottom-0 w-0.5 bg-gray-200" />
                            )}
                            <div className="absolute left-0 top-0.5 w-4 h-4 rounded-full bg-green-500 text-white flex items-center justify-center">
                              <Footprints className="w-2.5 h-2.5" />
                            </div>
                            <div className="bg-green-50 rounded p-2">
                              <div className="text-[10px] text-green-600 font-medium mb-0.5">
                                {useElytra ? '飞行' : '步行'} {Math.round(segment.distance)}m
                                <span className="text-gray-400 ml-1">({formatTime(walkTime)})</span>
                              </div>
                              <div className="text-xs text-gray-800">
                                <button className="text-green-700 hover:underline" onClick={() => onPointClick?.(segment.from)}>
                                  ({Math.round(segment.from.x)}, {Math.round(segment.from.z)})
                                </button>
                                <span className="text-gray-400 mx-1">→</span>
                                <button className="text-green-700 hover:underline" onClick={() => onPointClick?.(segment.to)}>
                                  ({Math.round(segment.to.x)}, {Math.round(segment.to.z)})
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      }

                      if (segment.type === 'teleport') {
                        const isReverseTP = segment.isReverse || segment.destinationName === segment.torii.name;
                        const toriiLabel = `#${segment.torii.id} ${segment.torii.name}`;

                        let fromName: string;
                        let toName: string;

                        if (isReverseTP) {
                          const prevSegment = index > 0 ? resultLegacy.segments[index - 1] : null;
                          if (prevSegment?.type === 'teleport') fromName = prevSegment.destinationName;
                          else fromName = segment.destinationName !== segment.torii.name ? segment.destinationName : '中转点';
                          toName = toriiLabel;
                        } else {
                          fromName = `任意位置 (${toriiLabel})`;
                          toName = segment.destinationName;
                        }

                        return (
                          <div key={index} className="relative pl-5">
                            {index < resultLegacy.segments.length - 1 && (
                              <div className="absolute left-[7px] top-5 bottom-0 w-0.5 bg-gray-200" />
                            )}
                            <div className="absolute left-0 top-0.5 w-4 h-4 rounded-full bg-purple-500 text-white flex items-center justify-center">
                              <Zap className="w-2.5 h-2.5" />
                            </div>
                            <div className="bg-purple-50 rounded p-2">
                              <div className="text-[10px] text-purple-600 font-medium mb-0.5">
                                传送 → {toName}
                                {isReverseTP && <span className="text-gray-400 ml-1">(+30秒)</span>}
                              </div>
                              <div className="text-xs text-gray-800">
                                <button
                                  className="text-purple-700 hover:underline"
                                  onClick={() => onPointClick?.(isReverseTP ? segment.destination : segment.torii.coord)}
                                >
                                  {fromName}
                                </button>
                                <span className="text-gray-400 mx-1">→</span>
                                <button
                                  className="text-purple-700 hover:underline"
                                  onClick={() => onPointClick?.(isReverseTP ? segment.torii.coord : segment.destination)}
                                >
                                  {toName}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      }

                      if (segment.type === 'rail') {
                        const railSegments = simplifyPath(segment.railPath.path);
                        const totalRailDist = segment.railPath.totalDistance;
                        const avgDistPerSeg = railSegments.length > 0 ? totalRailDist / railSegments.length : 0;

                        return railSegments.map((railSeg, railIndex) => {
                          const segDist = Math.sqrt(
                            Math.pow(railSeg.endCoord.x - railSeg.startCoord.x, 2) + Math.pow(railSeg.endCoord.z - railSeg.startCoord.z, 2)
                          );
                          const segTime = calculateRailTime(segDist || avgDistPerSeg);

                          return (
                            <div key={`${index}-${railIndex}`} className="relative pl-5">
                              {(railIndex < railSegments.length - 1 || index < resultLegacy.segments.length - 1) && (
                                <div className="absolute left-[7px] top-5 bottom-0 w-0.5 bg-gray-200" />
                              )}
                              <div className="absolute left-0 top-0.5 w-4 h-4 rounded-full bg-blue-500 text-white text-[10px] flex items-center justify-center">
                                <Train className="w-2.5 h-2.5" />
                              </div>
                              <div className="bg-blue-50 rounded p-2">
                                <div className="text-[10px] text-blue-600 font-medium mb-0.5">
                                  {formatLineName(railSeg.lineId)}
                                  <span className="text-gray-400 ml-1">({formatTime(segTime)})</span>
                                </div>
                                <div className="text-xs text-gray-800">
                                  <button className="hover:underline hover:text-blue-600" onClick={() => onPointClick?.(railSeg.startCoord)}>
                                    {railSeg.stations[0]}
                                  </button>
                                  {railSeg.stations.length > 2 && (
                                    <span className="text-gray-400 mx-1">→ {railSeg.stations.length - 2}站 →</span>
                                  )}
                                  {railSeg.stations.length === 2 && <span className="text-gray-400 mx-1">→</span>}
                                  {railSeg.stations.length > 1 && (
                                    <button className="hover:underline hover:text-blue-600" onClick={() => onPointClick?.(railSeg.endCoord)}>
                                      {railSeg.stations[railSeg.stations.length - 1]}
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        });
                      }

                      return null;
                    })}
                  </div>
                </>
              ) : (
                <div className="text-center text-gray-500 py-4 text-sm">
                  {startPoint?.coord.x === endPoint?.coord.x && startPoint?.coord.z === endPoint?.coord.z
                    ? '起点和终点相同'
                    : '未找到可用路线'}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default NavigationPanel;
